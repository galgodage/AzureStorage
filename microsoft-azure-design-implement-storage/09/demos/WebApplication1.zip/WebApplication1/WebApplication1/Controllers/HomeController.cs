﻿using Microsoft.Azure.Search;
using Microsoft.Azure.Search.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            var searchServiceName = "mikepf";
            var apiKey = "2AF36821942EFBF84C23FB5FBEF551C7";

            var searchClient = new SearchServiceClient(searchServiceName, new SearchCredentials(apiKey));
            var indexClient = searchClient.Indexes.GetClient("awindex2");

            SearchParameters sp = new SearchParameters() { SearchMode = SearchMode.All };
            var docs = indexClient.Documents.Search("A Bike Store", sp);

            return Json(docs.Results, JsonRequestBehavior.AllowGet);
        }
    }
}