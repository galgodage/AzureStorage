﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using ConsoleApp1.Entities;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
                CloudConfigurationManager.GetSetting("StorageConnection"));

            CloudTableClient tableClient = storageAccount.CreateCloudTableClient();

            CloudTable table = tableClient.GetTableReference("customers");

            table.CreateIfNotExists();

            var user = new CustomerUS("Mike", "mike@localhost.local");

            TableOperation insert = TableOperation.Insert(user);

            table.Execute(insert);

            Console.ReadKey();
        }

        static void CreateUser(CloudTable table, CustomerUS user)
        {
            TableOperation insert = TableOperation.Insert(user);

            table.Execute(insert);
        }
    }
}
